# CampusFlow ERP — College Management System
Project Author: SIKHA PRAJAPATI
Technology: HTML, CSS, JavaScript
Purpose: Academic / portfolio demonstration.

Modules: Dashboard, Students, Attendance, Results, Fees, Courses, Notices.

This project uses fictional demo data. It is not connected to a real college database.

## GitHub Pages
Create a public repository named `college-erp-system`, upload the three website files to the root, then enable Settings → Pages → Deploy from `main` branch / root.

The live URL will be:
https://YOUR-USERNAME.github.io/college-erp-system/

## Intellectual property
This project is prepared for SIKHA PRAJAPATI as an original portfolio/academic implementation. This statement does not itself create a patent or government registration. Patent rights require the applicable legal filing/grant process.
